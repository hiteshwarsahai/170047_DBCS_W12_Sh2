import java.sql.*;

/**
 * made by Hiteshwar Sahay
 */
class update { 
  
    public static void main (String[] args) { 
        try { 
            String url = "jdbc:msql://localhost:3036/sh"; 
            Connection conn = DriverManager.getConnection(url,"root","Hiteshwar Sahay"); 
            Statement st = conn.createStatement(); 
            st.executeUpdate("UPDATE week12 SET City = 'Chandigarh' WHERE Dept_id = 24;"); 
           
            conn.close(); 
        } catch (Exception e) { 
            System.err.println("Got an exception! "); 
            System.err.println(e.getMessage()); 
        } 
  
    }
} 