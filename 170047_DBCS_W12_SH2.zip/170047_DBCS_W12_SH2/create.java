

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * @author Hiteshwar Sahay
 */
public class create {
  
  private static final String CREATE_TABLE_SQL="CREATE TABLE week12("
                    + "Emp_ID int"
                    + "First_Name VARCHAR(45) NOT NULL,"
                    + "Last_Name VARCHAR(45) NOT NULL,"
                    + "EMAIL VARCHAR(45) NOT NULL,"
                    + "Salary int(45),"
					+ "Dept_ID int,"
					+ "City VARCHAR(45))";
  
  public static void main(String[] args) {
    String jdbcUrl = "jdbc:mysql://localhost:3306/sh";
    String username = "root";
    String password = "sawan";

    Connection conn = null;
    Statement stmt = null;

    try {

      conn = DriverManager.getConnection(jdbcUrl, username, password);
      stmt = conn.createStatement();

      stmt.executeUpdate(CREATE_TABLE_SQL);

      System.out.println("Table created");

    } catch (SQLException e) {
      e.printStackTrace();
    } finally {
      try {
        // Close connection
        if (stmt != null) {
          stmt.close();
        }
        if (conn != null) {
          conn.close();
        }
      } catch (Exception e) {
        e.printStackTrace();
      }
    }
  }
}